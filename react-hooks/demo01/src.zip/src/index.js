import React from 'react';
import ReactDOM from 'react-dom';
// import ReducerDemo from './Example6';
import Example9 from './example9';


ReactDOM.render(
  <React.StrictMode>
    <Example9/>
  </React.StrictMode>,
  document.getElementById('root')
);

